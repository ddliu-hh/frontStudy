<template>
  <li class="base-brand-item">
    <a href="#">
      <img src="@/assets/images/hot1.png" alt="" />
    </a>
  </li>
</template>

<script>
export default {

}
</script>

<style>
.base-brand-item {
  width: 244px;
  height: 306px;
}
</style>